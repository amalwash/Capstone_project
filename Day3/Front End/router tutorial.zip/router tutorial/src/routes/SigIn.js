import React from "react";

export default function SigIn() {
    return (
      <main style={{ padding: "1rem 0" }}>
      
      </main>
    );
  }