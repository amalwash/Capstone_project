
import React from "react";

export default function Home() {
    return (
      <main style={{ padding: "1rem 0" }}>
        <h2>Home</h2>
      </main>
    );
  }